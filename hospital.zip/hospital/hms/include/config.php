<?php
try {
    $conn = new PDO("sqlsrv:server = tcp:hms15.database.windows.net,1433; Database = HMS", "HMS", "{Karthi2007@1}");
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Error connecting to Azure SQL: " . $e->getMessage());
}

// SQL Server Extension for older implementations
$connectionInfo = array("UID" => "HMS", "pwd" => "{Karthi2007@1}", "Database" => "HMS", "LoginTimeout" => 30, "Encrypt" => 1, "TrustServerCertificate" => 0);
$serverName = "tcp:hms15.database.windows.net,1433";
$conn = sqlsrv_connect($serverName, $connectionInfo);

if ($conn === false) {
    die(print_r(sqlsrv_errors(), true));
}
?>
